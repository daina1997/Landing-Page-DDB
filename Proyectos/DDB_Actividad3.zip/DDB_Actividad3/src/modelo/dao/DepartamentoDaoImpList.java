package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Departamento;


public class DepartamentoDaoImpList implements IntDepartamentoDao{

	ArrayList<Departamento> lista;
	
	public DepartamentoDaoImpList() {
		lista= new ArrayList<Departamento>();
		cargarDatos();
	}
		
	private void cargarDatos() {
		LocalidadDaoImpList ldao = new LocalidadDaoImpList();
		lista.add(new Departamento(2001, "Agile", ldao.buscarUno(1001)));
		lista.add(new Departamento(2002, "EYS", ldao.buscarUno(1001)));
		lista.add(new Departamento(2003, "WWE", ldao.buscarUno(1004)));
		lista.add(new Departamento(2004, "Kras", ldao.buscarUno(1004)));
		
	}

	@Override
	public boolean alta(Departamento departamento) {
		if (lista.contains(departamento))
			return false;
		else 
			return lista.add(departamento);
	}

	@Override
	public boolean eliminar(int idDepartamento) {
		Departamento departamento = buscarUno(idDepartamento);
		if (departamento!=null) {
			return eliminar(departamento);
		}
		else 
			return false;
	}

	@Override
	public boolean eliminar(Departamento departamento) {
		return lista.remove(departamento);
	}

	@Override
	public boolean modificarUno(Departamento departamento) {
		int pos = lista.indexOf(departamento);
		if (departamento!=null) {
			lista.set(pos, departamento);
			return true;
		}
		else
			return false;
	}
	

	@Override
	public Departamento buscarUno(int idDepartamento) {
		Departamento departamento= new Departamento();
		departamento.setIdDepartamento(idDepartamento);
		int pos=lista.indexOf(departamento);
		if (pos!=-1) {
			return lista.get(pos);
		}
		else 
			return null;
	}

	@Override
	public ArrayList<Departamento> buscarTodos() {
		return lista;
	}

	@Override
	public ArrayList<Departamento> departPorLocalidad(int idLocalidad) {
		ArrayList<Departamento> auxList= new ArrayList<Departamento>();
		for (Departamento departamento:lista) {
			if (departamento.getLocalidad().getIdLocalidad()==idLocalidad)
				auxList.add(departamento);
		}
		return auxList;
	}
	
	
	
}
