package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Departamento;
import modelo.javabeans.Empleado;
import modelo.javabeans.Localidad;
import modelo.javabeans.Trabajo;


public class Empresa implements IntGestionEmpresa{
	
	private String nombre;
	private ArrayList<Empleado> plantilla;
	
	//Constructor sin parámetros:
	public Empresa() {
		nombre="";
		plantilla=new ArrayList<Empleado>();
		cargarDatos();
	}
	
	
	// Constructor con parámetros:
	
	public Empresa(String nombre) {
		this.nombre=nombre;
		plantilla=new ArrayList<Empleado>();
		cargarDatos();
	}
	
	//Método cargar datos:
	
	public void cargarDatos() {
		TrabajoDaoImpList tdao= new TrabajoDaoImpList();
		DepartamentoDaoImpList ddao = new DepartamentoDaoImpList();
		
		plantilla.add(new Empleado(403, "Valeria", "Haro Sol", "m", null, 28000, 2000,tdao.buscarUno("job_313") , ddao.buscarUno(2001)));
		plantilla.add(new Empleado(415, "Marco", "Hernandez Puig", "h", null, 38000, 3000, tdao.buscarUno("job_324"), ddao.buscarUno(2002)));
		plantilla.add(new Empleado(422, "Juana", "Perez Medina", "M", null, 30000, 5000, tdao.buscarUno("job_356"), ddao.buscarUno(2003)));
		plantilla.add(new Empleado(430, "Pedro", "Carmona Lopez", "H", null, 32000, 3000, tdao.buscarUno("job_313"), ddao.buscarUno(2004)));
		
		//Después de haber creado todas las clases Dao y sus interface me he dado cuenta que también 
		//podría haber creado la plantilla de esta manera...:
		
		plantilla.add(new Empleado(444, "Arnau", "Baena Vega", "h", null, 30000, 2000, 
				      new Trabajo("job_388","Carpintero", 25000, 35000),
				      new Departamento(2005, "LEGA", 
				      new Localidad(1003, "C/Casado nº4", "Bogotá", "Colombia"))));
		
	}
	
	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	@Override
	public boolean alta(Empleado empleado) {
		if (plantilla.contains(empleado)){
			return false;
		}
		else
			return plantilla.add(empleado);
		
	}

	@Override
	public boolean eliminarUno(Empleado empleado) {
		return plantilla.remove(empleado);
	}

	@Override
	public boolean modificarUno(Empleado empleado) {
		int pos = plantilla.indexOf(empleado);
		if (empleado!=null) {
			plantilla.set(pos, empleado);
			return true;
		}
		else 
			return false;
	}

	//COn el ignore case consigo que tanto M como m se consideren lo mismo y me filtre por mujeres y hombres independientemente de si es mayúsculas o no
	@Override
	public ArrayList<Empleado> buscarPorSexo(String genero) {
		ArrayList<Empleado> auxList= new ArrayList<Empleado>();
		for(Empleado empleado:plantilla) {
			if (empleado.getGenero().equalsIgnoreCase(genero)) {
				auxList.add(empleado);
			}
		}
		return auxList;
	}

	@Override
	public Empleado buscarUno(int idEmpleado) {
		Empleado empleado = new Empleado();
		empleado.setIdEmpleado(idEmpleado);
		int pos=plantilla.indexOf(empleado);
			if (pos!=-1) {
				return plantilla.get(pos);			
			}
			else
				return null;
	}

	@Override
	public ArrayList<Empleado> buscarTodos() {
		return plantilla;
	}

	
	@Override
	public double masaSalarial() {
		double masaSalarial=0;
		for(Empleado empleado:plantilla) {
			masaSalarial+=(empleado.getSalario()+ empleado.getComision());
		}
		return masaSalarial;
	}

	@Override
	public ArrayList<Empleado> buscarPorDepartamento(int idDepartamento) {
		ArrayList<Empleado> auxList= new ArrayList<Empleado>();
		for (Empleado empleado:plantilla) {
			if (empleado.getDepartamento().getIdDepartamento()==idDepartamento) {
				auxList.add(empleado);
			}
		}
		return auxList;
	}

	@Override
	public ArrayList<Empleado> buscarPorTrabajo(String idTrabajo) {
		ArrayList<Empleado> auxList= new ArrayList<Empleado>();
		for (Empleado empleado:plantilla) {
			if (empleado.getTrabajo().getIdTrabajo()==idTrabajo) {
				auxList.add(empleado);
			}	
		}
		return auxList;
	}

	@Override
	public ArrayList<Empleado> buscarPorPais(String pais) {
		ArrayList<Empleado> auxList= new ArrayList<Empleado>();
		for (Empleado empleado:plantilla) {
			if (empleado.getDepartamento().getLocalidad().getPais()==pais)
				auxList.add(empleado);
		}
		return auxList;
	}
	
}
