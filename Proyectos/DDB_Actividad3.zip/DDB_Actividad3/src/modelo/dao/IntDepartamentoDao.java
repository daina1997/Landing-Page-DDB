package modelo.dao;

import java.util.ArrayList;


import modelo.javabeans.Departamento;


public interface IntDepartamentoDao {

	boolean alta (Departamento departamento);
	boolean eliminar(int idDepartamento);
	boolean eliminar (Departamento departamento);
	boolean modificarUno (Departamento departamento);
	Departamento buscarUno(int idDepartamento);
	ArrayList<Departamento> buscarTodos();
	
	// Quiero saber cuantos departamentos tiene X localidad:
	ArrayList<Departamento> departPorLocalidad(int idLocalidad);
}
