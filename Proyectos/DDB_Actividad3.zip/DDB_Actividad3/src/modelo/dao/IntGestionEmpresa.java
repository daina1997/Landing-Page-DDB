package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Empleado;

public interface IntGestionEmpresa {

	boolean alta (Empleado empleado);
	boolean eliminarUno (Empleado empleado);
	boolean modificarUno (Empleado empleado);
	ArrayList<Empleado> buscarPorSexo(String genero);
	Empleado buscarUno(int idEmpleado);
	ArrayList<Empleado> buscarTodos();
	double masaSalarial();
	
	// Quiero saber cuantos trabajadores pertenecen X departamento:
	ArrayList<Empleado> buscarPorDepartamento(int idDepartamento);
	// Quiero saber cuantos trabajadores tienen X trabajo:
	ArrayList<Empleado> buscarPorTrabajo (String idTrabajo);
	// Quiero saber cuantos trabajadores en X pais:
	ArrayList<Empleado> buscarPorPais(String pais);

	



}
