package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Localidad;


public interface IntLocalidadDao {
	boolean alta (Localidad localidad);
	boolean eliminar(int idLocalidad);
	boolean eliminar (Localidad localidad);
	boolean modificarUno (Localidad localidad);
	Localidad buscarUno(int idLocalidad);
	ArrayList<Localidad> buscarTodos();

}
