package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Trabajo;

public interface IntTrabajoDao {
	boolean alta (Trabajo trabajo);
	boolean eliminar(String idTrabajo);
	boolean eliminar (Trabajo trabajo);
	boolean modificarUno (Trabajo trabajo);
	ArrayList<Trabajo> buscarTodos();
	Trabajo buscarUno(String idTrabajo);
}
