package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Localidad;


public class LocalidadDaoImpList implements IntLocalidadDao {
	
	ArrayList<Localidad> lista;
	public LocalidadDaoImpList() {
		lista= new ArrayList<Localidad>();
		cargarDatos();
	}
	private void cargarDatos() {
		lista.add(new Localidad(1001, "Av. Bilbao nº1", "Madrid", "España"));
		lista.add(new Localidad(1004, "Av. Luxemburgo nº16", "Berlin", "Alemania"));
	}
	
	
	@Override
	public boolean alta(Localidad localidad) {
		if (lista.contains(localidad))
			return false;
		
		else 
			return lista.add(localidad);
	}
	
	@Override
	public boolean eliminar(int idLocalidad) {
		Localidad localidad = buscarUno(idLocalidad);
		if (localidad !=null)
			return eliminar(localidad);
		else 
			return false;
	}
	
	@Override
	public boolean eliminar(Localidad localidad) {
		return lista.remove(localidad);
	}
	
	@Override
	public boolean modificarUno(Localidad localidad) {
		int pos = lista.indexOf(localidad);
		if (pos != -1) {
			lista.set(pos, localidad);
			return true;
		}
		else
			return false;
	}
	
	@Override
	public Localidad buscarUno(int idLocalidad) {
		Localidad localidad= new Localidad();
		localidad.setIdLocalidad(idLocalidad);;
		int pos=lista.indexOf(localidad);
		if (pos!=-1) {
			return lista.get(pos);
		}
		else
			return null;
	}
	
	@Override
	public ArrayList<Localidad> buscarTodos() {
		return lista;
	}
	
}
