package modelo.dao;

import java.util.ArrayList;

import modelo.javabeans.Trabajo;

public class TrabajoDaoImpList implements IntTrabajoDao {
	
	ArrayList<Trabajo> lista;
	
	public TrabajoDaoImpList() {
		lista = new ArrayList<Trabajo>();
		cargarDatos();
	}
	
	private void cargarDatos() {
		lista.add(new Trabajo("job_313", "Programador", 25000, 40000));
		lista.add(new Trabajo("job_324", "Director", 35000, 45000));
		lista.add(new Trabajo("job_356", "Médico", 30000, 50000));
	}

	
	@Override
	public boolean alta(Trabajo trabajo) {
		if (lista.contains(trabajo))
			return false;
		
		else 
			return lista.add(trabajo);
	}

	@Override
	public boolean eliminar(String idTrabajo) {
		Trabajo trabajo = buscarUno(idTrabajo);
		if (trabajo !=null)
			return eliminar(trabajo);
		else 
			return false;
	}

	@Override
	public boolean eliminar(Trabajo trabajo) {
		return lista.remove(trabajo);
	}

	@Override
	public boolean modificarUno(Trabajo trabajo) {
		int pos = lista.indexOf(trabajo);
		if (pos != -1) {
			lista.set(pos, trabajo);
			return true;
		}
		else
			return false;
	}

	@Override
	public ArrayList<Trabajo> buscarTodos() {
		return lista;
	}

	@Override
	public Trabajo buscarUno(String idTrabajo) {
		Trabajo trabajo= new Trabajo();
		trabajo.setIdTrabajo(idTrabajo);
		int pos=lista.indexOf(trabajo);
		if (pos!=-1) {
			return lista.get(pos);
		}
		else
			return null;
		
	}
	
	
}
