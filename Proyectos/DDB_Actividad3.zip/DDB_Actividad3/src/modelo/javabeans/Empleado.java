package modelo.javabeans;

import java.util.Objects;

public class Empleado {
	private int idEmpleado;
	private String nombre, apellidos, genero,email;
	private double salario, comision;
	private Trabajo trabajo;
	private Departamento departamento;
	
	// Constructor con parámetros:
	
	public Empleado(int idEmpleado, String nombre, String apellidos, String genero, String email, double salario,
			double comision, Trabajo trabajo, Departamento departamento) {
		super();
		this.idEmpleado = idEmpleado;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.genero = genero;
		this.email = obtenerEmail(nombre, apellidos); //EL hecho de poner el método nos permite obtener el email de manera automática cuando sacas la información del empleado.
		this.salario = salario;
		this.comision = comision;
		this.trabajo = trabajo;
		this.departamento = departamento;
	}
	
	//Constructor sin parámetros:
	
	public Empleado() {
		super();
	}
	
	//Métodos própios:
	
	public double salarioBruto() {
		return(this.salario + this.comision);
	}
	
	public double salarioMensual(int meses) {
		return (this.salario/meses);
	}
	
	public String literalSexo() {
		String literal=null;
		
		switch(this.genero) {
		case "M": case "m":
			literal="Mujer";
			break;
		case "H": case "h" :
			literal="Hombre";
			break;
		default:
			literal="Género incorrecto";
		}
		
		return literal;
	}
	
	public String nombreCompleto() {
		return (this.nombre +" " + this.apellidos);
	}
	
	public static String obtenerEmail(String nombre, String apellidos) {
		String primeraLetraNombre= nombre.substring(0, 1).toLowerCase();
		String[] parteApellidos= apellidos.split(" ");
		String primerApellido= parteApellidos[0].toLowerCase();
		String email=primeraLetraNombre+primerApellido+"@gmail.com";
		return email;
	}
	
	//Getters and Setters: 
	
	public int getIdEmpleado() {
		return idEmpleado;
	}
	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getComision() {
		return comision;
	}
	public void setComision(double comision) {
		this.comision = comision;
	}
	public Trabajo getTrabajo() {
		return trabajo;
	}
	public void setTrabajo(Trabajo trabajo) {
		this.trabajo = trabajo;
	}
	public Departamento getDepartamento() {
		return departamento;
	}
	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	
	//Hash code + equals:
	
	@Override
	public int hashCode() {
		return Objects.hash(idEmpleado);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Empleado))
			return false;
		Empleado other = (Empleado) obj;
		return idEmpleado == other.idEmpleado;
	}
	
	//To String:
	@Override
	public String toString() {
		return "Empleado [idEmpleado=" + idEmpleado + ", nombre=" + nombre + ", apellidos=" + apellidos + ", genero="
				+ genero + ", email=" + email + ", salario=" + salario + ", comision=" + comision + ", trabajo="
				+ trabajo + ", departamento=" + departamento + "]";
	}
	
	

}
