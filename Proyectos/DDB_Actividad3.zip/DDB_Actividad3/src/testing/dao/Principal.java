package testing.dao;

import modelo.dao.DepartamentoDaoImpList;
import modelo.dao.Empresa;
import modelo.dao.TrabajoDaoImpList;
import modelo.javabeans.Empleado;


public class Principal {

	
	private static Empresa emp;
	private static TrabajoDaoImpList tdao;
	private static DepartamentoDaoImpList ddao;
	
	static {
		emp=new Empresa();
		tdao=new TrabajoDaoImpList();
		ddao=new DepartamentoDaoImpList();
	}
	
	
	
	public static void main(String[] args) {
		// Comprobación métodos:
		
			System.out.println("1"); 
			alta();
			System.out.println("----------------------------");
			
			System.out.println("2"); 
			eliminarUno();
			System.out.println("----------------------------");
			
			System.out.println("3"); 
			modificarUno();
			System.out.println("----------------------------");
			
			System.out.println("4"); 
			buscarPorSexo();
			System.out.println("----------------------------");
			
			System.out.println("5"); 
			buscarUno();
			System.out.println("----------------------------");
			
			System.out.println("6"); 
			buscarTodos();
			System.out.println("----------------------------");
			
			System.out.println("7"); 
			masaSalarial();
			System.out.println("----------------------------");
			
			System.out.println("8"); 
			buscarPorDepartamento();
			System.out.println("----------------------------");
			
			System.out.println("9"); 
			buscarPorTrabajo();
			System.out.println("----------------------------");
			
			System.out.println("10"); 
			buscarPorPais();
			
	}
	
	public static void alta() {
		
		Empleado empleado = new Empleado(409, "Laura", "Navas Navarro", "M", "", 25000, 3000, tdao.buscarUno("job_313"), ddao.buscarUno(2001));
		//Tal y como he comentado en Empresa, también podría haberlo hecho de esta manera, en la que con solo importar las clases javabeans
		//y usar el constructor ya hubiese sido suficiente, sin necesidad de crear las otras clases Dao ni sus interfaces:
		
		/*Empleado empleado = new Empleado(409, "Laura", "Navas Navarro", "M", "", 25000, 3000, 
		  					new Trabajo("job_313", "Programador", 25000, 35000), 
							new Departamento(2001, "Agile", 
							new Localidad(1001, "Av. Bilbao nº1", "Madrid", "España")));*/
		
		
		System.out.println(emp.alta(empleado)); //así sabemos si se ha hecho o no.
		
	}
	
	public static void eliminarUno(){
		System.out.println(emp.eliminarUno(emp.buscarUno(409)));
	}
	
	public static void modificarUno() {
		Empleado empleado= emp.buscarUno(422);
		empleado.setNombre("Samanta");
		System.out.println(emp.modificarUno(empleado));
		
	}
	public static void buscarPorSexo() {
		for (Empleado empleado:emp.buscarPorSexo("h"))
		System.out.println(empleado);
	}
	
	public static void buscarUno() {
		System.out.println(emp.buscarUno(415));
	}
	
	public static void buscarTodos() {
		for (Empleado empleado:emp.buscarTodos())
		System.out.println(empleado);
	}
	
	public static void masaSalarial() {
		System.out.println(emp.masaSalarial());	
	}
	
	public static void buscarPorDepartamento() {
		for (Empleado empleado:emp.buscarPorDepartamento(2003))
			System.out.println(empleado);
		
	}
	
	public static void buscarPorTrabajo() {
		for (Empleado empleado:emp.buscarPorTrabajo("job_313"))
			System.out.println(empleado);
	}
	
	public static void buscarPorPais() {
		for (Empleado empleado:emp.buscarPorPais("Alemania"))
			System.out.println(empleado);
	}

	
	
	
	

}
