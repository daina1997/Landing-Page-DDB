package testing.dao;

import modelo.dao.TrabajoDaoImpList;
import modelo.javabeans.Trabajo;

public class TestingDaoTrabajo {

	private static TrabajoDaoImpList tdao;
	
	static {
		tdao=new TrabajoDaoImpList();
	}
	
	
	public static void main(String[] args) {
		//Probamos todos los métodos del interface.
				//alta();
				//buscarTodos();
				//buscarUno();
				//eliminar();
				//modificarUno();

	}
	
	public static void alta() {
		Trabajo trabajo = new Trabajo("job_111", "lalal", 1000, 2000);
		System.out.println(tdao.alta(trabajo));
	}

	public static void buscarTodos() {
		for (Trabajo trabajo: tdao.buscarTodos())
			System.out.println(trabajo);
	}
	
	public static void eliminar() {
		System.out.println(tdao.eliminar("job_313"));
		System.out.println(tdao.eliminar(tdao.buscarUno("job_122")));
	}
	public static void modificarUno() {
		Trabajo trabajo= tdao.buscarUno("job_313");
		trabajo.setDescripcion("Carpintero");
		System.out.println(tdao.modificarUno(trabajo));
		buscarTodos();
	}
}
