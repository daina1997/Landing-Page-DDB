package testing.javabeans;

import modelo.javabeans.Departamento;
import modelo.javabeans.Empleado;
import modelo.javabeans.Localidad;
import modelo.javabeans.Trabajo;

public class TestingEmpleado {

	public static void main(String[] args) {
		
		Localidad local_1=new Localidad(1001, "Av. Bilbao nº1", "Madrid", "España");
		Localidad local_2=new Localidad(1001, "Av. Barcelona nº23", "Valencia", "España");
		
		Departamento depart_1= new Departamento(2001, "Agile", local_1);
		Departamento depart_2= new Departamento(2002, "IT", local_2);
		
		Trabajo job_1=new Trabajo("job_301", "Profesor", 20000, 35000);
		//He creado el objeto Empleado sin email para comprobar que funcionase el método obtener email.
		Empleado emp_1=new Empleado(401, "Maria", "Gómez Navarro", "M", "",30000, 500, job_1, depart_1);
		Empleado emp_2=new Empleado(402, "Sergio", "Hernandez Díaz", "h",null,30000, 900, job_1, depart_2);
		
		//El hecho de haber relacionado las clases entre si, me permite (a través del get) obtener de la clase empleado la información de las otras clases.
		System.out.println("Empleada 1:" + emp_1.getNombre()+ " , "
							+ emp_1.getApellidos() + " , " 
							+ emp_1.literalSexo() + " , " 
							+ emp_1.getDepartamento().getDescripcion() + " , "
							+ emp_1.getTrabajo().getDescripcion()+ " , "
							+ emp_1.getDepartamento().getLocalidad().getDireccion()+ " , "
							+ emp_1.getDepartamento().getLocalidad().getCiudad() + " , "
							+ emp_1.getDepartamento().getLocalidad().getPais());
		
		System.out.println("Comprobación método email:" + emp_1.getEmail());
		
		
		
		System.out.println("Empleado 2:" + emp_2.nombreCompleto() + " , " 
				+ emp_2.literalSexo() + " , " 
				+ emp_2.salarioBruto()+ " , " 
				+ emp_2.salarioMensual(12)+ " , " );
		
		System.out.println("Extraer del empleado2 su trabajo:" + emp_2.getTrabajo().getIdTrabajo()+ " , " + emp_2.getTrabajo().getDescripcion()
							+ " // "+ "Y su departamento:" + emp_2.getDepartamento().getIdDepartamento()+ " , " + emp_2.getDepartamento().getDescripcion());
		
		
	}
	


}
